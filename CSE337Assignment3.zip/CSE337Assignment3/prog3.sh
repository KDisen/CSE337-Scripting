#!/bin/sh

#Keven Disen
#CSE 337
#Assignment 3 Problem 3
#Nov 16, 2020

if test -f $1
then

  #the number fields should be the number of inputs, to put into array
  arraylength=$(awk 'BEGIN {FS = ","} END{print NF-1;}' $1)
  array=( "${@:2:$arraylength}" )
  #if an input is missing then it should be 1
  amount=$#
  update=`expr $amount - 1`
  counter=0
  for (( i=0;i<$arraylength; i++ ))
  do
    counter=$((counter+1))
    if [[ $counter -eq $update ]]
    then
      if [[ ! $counter -eq $arraylength ]]
      then
        array+=(1)
        update=$((update+1))
      fi
    fi
  done
  
  sumWeights=$(IFS=+; echo "$((${array[*]}))")



  #round down towards 0
  weightedAverage=$(awk -v array1="${array[*]}" -v sum=$sumWeights ' {FS = ","} {arr=split(array1,array," ");}
    {ID[i]=$1} {for (i=2; i<=NF; i++) q[i-1]=$i}
    NR>1 {for (j=1;j<=NF;j++) for (z=1;z<=NF;z++) (a[j] += q[z]*array[z])}
    END {print int(((a[1]/sum)/(NR-1)))}' $1)

  echo $weightedAverage

else
  echo "missing data file"
fi
