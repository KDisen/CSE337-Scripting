#!/bin/sh

#Keven Disen
#CSE 337
#Assignment 3 Problem 5
#Nov 16, 2020

#There should only be 2 inputs, if less or more displays message that is missing one or the other
if [ $# -eq 2 ]
then
  #checks if file doesn't exist
  if [ ! -f $1 ]
  then
    echo "$1 is not a file"
  else

    #checks if file inputted doesn't exist
    if [ ! -f $2 ]
    then
      echo "$2 is not a file"
    else
      #gets the amount of lines in the dictionary file to create the array
      arrlength=$(awk 'END {print NR}' $2)

      #adds dictionary words into an array
      for (( i=0; i<=${arrlength}; i++ ));
      do
        arr+=($(awk -v var=$i 'FNR == var {print}' $2))
      done

      #reads the input file word by word, if the 4 lettered word matches the dictionary then it's fine, if not should print to console
      DONE=false
      until $DONE; do
        read line || DONE=true
        for word in $line; do
          #checks if 4 letters
          if [ ${#word} -eq 4 ]
          then
            #not case sensitive
            shopt -s nocasematch
            #prints word if spelled incorrectly
            if [[ ! " ${arr[*]} " == *"$word"* ]]; then
              echo "$word"
            fi
          fi
        done
      done <$1
    fi
  fi

else
  echo "input file and dictionary missing"
fi
