#!/bin/sh

#Keven Disen
#CSE 337
#Assignment 3 Problem 2
#Nov 16, 2020

#if inputs are not provided, then no data/output file
if [ $# -eq 2 ]
then

  #if data file does not exist, say not found
  if [ -f $1 ]
  then

    #use a helper file to convert to make all of the field separators the same
    sed -e 's/;/,/g' -e 's/:/,/g' $1 > helper.txt

    #Add columns together and get sum of each
    awk 'BEGIN {FS = ","} {for (i=1;i<=NF;i++) sum[i]+=$i;} END{for (i=1;i<=NF;i++) print "Col "i": " sum[i];}' helper.txt > $2

    rm helper.txt

  else
    echo "$1 not found"
  fi
else
  echo "data file or output file not found"
fi
