#!/bin/sh

#Keven Disen
#CSE 337
#Assignment 3 Problem 4
#Nov 16, 2020

#There should only be 1 input
if [ $# -eq 1 ]
then

  #checks if input is a directory
  if test -d $1
  then
    cd $1

    #goes through each file in the directory and reads the scores of each questions and prints out letter grade
    for i in `ls`
    do
      scores=$(awk '{FS = ","} {ID=$1} NR>1 {for (i=2;i<=NF;i++) grade += $i} END {percent = int(((grade/50)*100));
      if (percent > 93) {print ID ":A"} else if (percent > 80 && percent < 92) {print ID ":B"}
    else if (percent > 65 && percent < 79) {print ID ":C"}
    else if (percent < 65) {print ID ":D"}}' $i)
      echo $scores
    done
  else
    echo "$1 is not a directory"
  fi
else
  echo "score directory missing"
fi
