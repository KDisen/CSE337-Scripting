#!/bin/sh

#Keven Disen
#CSE 337
#Assignment 3 Problem 1
#Nov 16, 2020

#created method if the file is not a .c file
nonCfiles(){
  if test -f $1
  then
    if ! [[ $1 == *.c* ]]
    then
      rm $1
    fi
  fi
}

#created method to read files if there's more than 3 .c files
readFiles() {

  for i in `ls -1`
  do
    if test -f $i
    then
      echo $i
      files+=($i)
    fi
  done
  echo "Move? Y or N"
  read choice
  echo "here"
  case $choice in
    y|Y) echo saved ;;
    n|N) rm ${files[*]} ;;
  esac
  files=()
  for j in `ls`
  do
    nonCfiles $j
    if test -d $j
      then
        cd $j
        amount=`ls -dq *.c* | wc -l`
        three=3
        if [ $amount -ge $three ]
        then
          readFiles
        fi
        cd ..
      fi
  done
}

#main
if [ $# -eq 2 ]
then
  #if source dir doesn't exist, exit with status 0 and display message
  if [ ! -d $1 ]
  then
    echo "$1 was not found"
    exit 0;
  else

    #if input doesn't exist, create the directory.
    #if it does, remove everything that's within the directory
    if [ ! -d $2 ]
    then
      mkdir $2
    else
      echo "$2 already created"
      rm -r $2
      mkdir $2
    fi

    #copying the files and subdirs into the destination directory
    cp -R $1/* $2
    cd $2

    #if there's a directory, check for amount of .c files in the directory,
      #if more than 3 should go to readFiles method and prompt user if they want to move it over
    for i in `ls`
    do
      if test -d $i
      then

        amount=`ls -dq *.c* | wc -l`
        three=3
        if [ $amount -ge $three ]
        then
          readFiles
        fi
        cd ..

      #If there's no directory then go to nonCFiles method, which removes the .o files from the destination directory
      else
        nonCfiles "$i"
      fi
    done
  fi
else
  echo "src and dest dirs missing"
fi
