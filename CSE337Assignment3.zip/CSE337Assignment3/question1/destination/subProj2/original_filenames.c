Bruh this is odee
creating folders and files
maa
work dude
