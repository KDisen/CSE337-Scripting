Hello this is a c script
It should read this
hope it does
song is hitting
