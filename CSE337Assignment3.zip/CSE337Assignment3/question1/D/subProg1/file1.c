YOOO
KLOK
gua happen mi friend
