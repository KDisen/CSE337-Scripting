class Array
  alias old [] #saves
  def [](ind)
    if ind >= length
      return '\0'
    else
      return old(ind)
    end
  end
  def map(index=nil)
    arr = []
    x=0
    if index == nil
      while x!=length
        arr.append(yield(old(x)))
        x = x+1
      end
      return arr
    else
      for i in old(index) do
        arr.append(yield(i))
      end
      return arr
    end
  end
end
