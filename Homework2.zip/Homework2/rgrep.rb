#Keven Disen
#111433335
#CSE 337
#Assignment 2 Problem 2
# October 19

#puts arguments into variable
args = ARGV

#handling exceptions
begin
  #if file exists go through file
  if File.file?(args[0]) or args[0] == nil
    fileName = args[0]
    pattern = args[-1]

    #looks for word in file and returns line
    if args[1] == '-w'
      if args[2].match(/^-/)
        #return number of lines matched
        if args[2] == '-c'
          count1 = 0
          File.readlines(fileName).select {|num| count1 +=1 if num =~ /\b#{pattern}\b/}
          puts count1

        #return matched part
        elsif args[2] == '-m'
          lines = []
          words = []
          File.open(fileName) do |f|
            f.each_line do |line|
              arr = line.split(' ')
              arr.each do |word|
                lines.append(word)
              end
            end
            for i in lines
              if i =~ /\b#{pattern}\b/
                words.append(i)
              end
            end
          end
          puts words
        else
          puts "Invalid Option"
        end

      #return lines that contain the word
      else
        File.open(fileName).each_line do |line|
          puts line if line.match(/\b#{pattern}\b/)
        end
      end

    #searches for pattern and returns lines that do not match
    elsif args[1] == '-v'
      if args[2].match(/^-/)
        #return number of lines that match
        if args[2] == '-c'
          count2 = 0
          File.open(fileName).each_line do |line|
            count2 +=1 unless line.match? /#{pattern}/
          end
          puts count2
        else
          puts "Invalid combination of options"
        end

        #if empty return invalid combo
      elsif args[2] == nil
        puts "Invalid combination of options"

      #if regexp instead of option, return lines that do not match
      else
        File.open(fileName).each_line do |line|
          puts line unless line.match? /#{pattern}/
        end
      end


    #searches for pattern and return lines that match
    elsif args[1] == '-p'
      if args[2].match(/^-/)
        #return amount of lines that word matched
        if args[2] == '-c'
          count3 = 0
          File.readlines(fileName).select {|num| count3 +=1 if num =~ /#{pattern}/}
          puts count3

        elsif args[2] == '-m'
          lines = []
          words = []
          File.open(fileName) do |f|
            f.each_line do |line|
              arr = line.split(' ')
              arr.each do |word|
                lines.append(word)
              end
            end
            for i in lines
              if i =~ /\b#{pattern}\b/
                words.append(i)
              end
            end
          end
          puts words
        else
          puts "Invalid Option"
        end


      #if pattern is in argument, return all lines that match
      else
        File.open(fileName).each_line do |line|
          puts line if line.match(/#{pattern}/)
        end
      end

    #if options start with these conjuctions they are invalid
    elsif args[1] == '-c' or args[1] == '-m'
      if args[1] == '-c'
        count3 = 0
        File.readlines(fileName).select {|num| count3 +=1 if num =~ /#{pattern}/}
        puts count3

      elsif args[2] == '-m'
        lines = []
        words = []
        File.open(fileName) do |f|
          f.each_line do |line|
            arr = line.split(' ')
            arr.each do |word|
              lines.append(word)
            end
          end
          for i in lines
            if i =~ /\b#{pattern}\b/
              words.append(i)
            end
          end
        end
        puts words
      end

    #If empty, then missing
    elsif args[1] == nil
      puts "Missing required arguments"

    #If there's a regex find and match, This is -p default
    else
      count4 = 0
      File.open(fileName).each_line do |line|
        if count4 == 0
          puts "Invalid Option"
          count4+=1
        else
          if line.match(/#{pattern}/)
            puts line
          end
        end

      end
    end
  end

#If can't find file return this
rescue Exception => e
  puts "Missing required arguments"
end
