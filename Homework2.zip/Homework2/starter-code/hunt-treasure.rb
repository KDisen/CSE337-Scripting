#Keven Disen
#111433335
#CSE 337
#Assignment 2 Problem 3
#October 19

require 'set'

class Room
  #initializing room numbers
  def initialize(num)
    @num = num
    @insideRoom = []
    @connectedRooms = []
  end

  #getters
  def number
    @num
  end
  def neighbors
    @connectedRooms
  end
  def inside
    @insideRoom
  end

  #checking if room is empty
  def empty?
    if @insideRoom.empty?
      return true
    else
      return false
    end
  end

  #adding object to room
  def add(object)
    @insideRoom.append(object)
  end
  #removing object in room
  def remove(object)
    index = 0
    for i in @insideRoom
      if object == i
        @insideRoom.delete_at(index)
      else
        index +=1
      end
    end
  end
  #checking if room has object
  def has?(object)
    if @insideRoom.empty?
      return false
    else
      for i in @insideRoom
        if object == i
          return true
        else
          return false
        end
      end
    end
  end
  #connects room to one instance
  def connect(otherRoom)
    @connectedRooms.append(otherRoom)
    #should be bi-directional way
    otherRoom.neighbors.append(self)
    i = 0
    unless i = @connectedRooms.length
      if connectedRooms[i] == self
        self.remove(i)
      end
    end
  end

  #returns the neighbor
  def neighbor(nextRoom)
    for i in @connectedRooms
      if i.number == nextRoom
        return i
      end
    end
  end

  #returns the different exits of a room
  def exits
    arr = []
    for i in @connectedRooms
      arr.append(i.number)
    end
    return arr
  end

  #returns a random neighbor
  def random_neighbor
    random = rand(@connectedRooms.length)
    return @connectedRooms[random]
  end

  #checks if the room is safe
  def safe?
    if @insideRoom.empty?
      for i in @connectedRooms
        if i.empty?
          return true
        else return false
        end
      end
    else
      return false
    end
  end

  #dont really need, but shows what room is connected to what

end

# #test Cases
# rm = Room.new(12)
# rm.number === 12
# rm.empty?
# rm.add(:bats)
# rm.safe?
# rm.remove(:bats)
# rm.has?(:bats)
# exit_numbers = [11, 3, 7]
# exit_numbers.each {|i|
#   rm.connect(Room.new(i))
# }
# # print rm.neighbors
# exit_numbers.each {|i|
#   rm.neighbor(i).number == i
#   rm.neighbor(i).neighbor(rm.number) == rm
# }
# # puts rm
# # print rm.exits == exit_numbers
# # puts exit_numbers.include?(rm.random_neighbor.number)
# rm.safe?


class Cave
  def initialize
    @@cueva = []
  end
  def self.dodecahedron
    cave = Cave.new()
    i = 1
    while i !=21
      room = Room.new(i)
      @@cueva.append(room)
      i +=1
    end
    for i in @@cueva
      if i.number == 1
        i.neighbors.append(@@cueva[1],@@cueva[4], @@cueva[7])
      elsif i.number == 2
        i.neighbors.append(@@cueva[0],@@cueva[2], @@cueva[9])
      elsif i.number == 3
        i.neighbors.append(@@cueva[3],@@cueva[11], @@cueva[1])
      elsif i.number == 4
        i.neighbors.append(@@cueva[2],@@cueva[4], @@cueva[13])
      elsif i.number == 5
        i.neighbors.append(@@cueva[0],@@cueva[5], @@cueva[3])
      elsif i.number == 6
        i.neighbors.append(@@cueva[4],@@cueva[6], @@cueva[14])
      elsif i.number == 7
        i.neighbors.append(@@cueva[5],@@cueva[16], @@cueva[7])
      elsif i.number == 8
        i.neighbors.append(@@cueva[6],@@cueva[10], @@cueva[0])
      elsif i.number == 9
        i.neighbors.append(@@cueva[9],@@cueva[11], @@cueva[18])
      elsif i.number == 10
        i.neighbors.append(@@cueva[10],@@cueva[8], @@cueva[1])
      elsif i.number == 11
        i.neighbors.append(@@cueva[19],@@cueva[9], @@cueva[7])
      elsif i.number == 12
        i.neighbors.append(@@cueva[12],@@cueva[2], @@cueva[8])
      elsif i.number == 13
        i.neighbors.append(@@cueva[11],@@cueva[17], @@cueva[13])
      elsif i.number == 14
        i.neighbors.append(@@cueva[12],@@cueva[14], @@cueva[3])
      elsif i.number == 15
        i.neighbors.append(@@cueva[5],@@cueva[15], @@cueva[13])
      elsif i.number == 16
        i.neighbors.append(@@cueva[16],@@cueva[17], @@cueva[14])
      elsif i.number == 17
        i.neighbors.append(@@cueva[15],@@cueva[19], @@cueva[6])
      elsif i.number == 18
        i.neighbors.append(@@cueva[18],@@cueva[15], @@cueva[12])
      elsif i.number == 19
        i.neighbors.append(@@cueva[8],@@cueva[19], @@cueva[17])
      else
        i.neighbors.append(@@cueva[18],@@cueva[10], @@cueva[16])
      end
    end
    return cave
  end


  def room(rooms)
    for i in @@cueva
      if i.number == rooms
        return i
      end
    end
  end

  def show
    return @@cueva
  end
  def random_room
    return @@cueva[rand(20)]
  end
  def move(obj, from, dest)
    for i in @@cueva
      if i == from
        i.remove(obj)
      end
    end
    for j in @@cueva
      if j == dest
        j.add(obj)
      end
    end
  end
  def add_hazard(obj, amount)
    j = 0
    while j != amount
      i = @@cueva[rand(@@cueva.length)]
      if i.has?(obj) == false
        i.add(obj)
      end
      j+=1
    end
  end

  def room_with(obj)
    for i in @@cueva
      if i.has?(obj)
        return i
      end
    end
  end

  def entrance
    for i in @@cueva
      if i.safe?
        return i
      end
    end
  end

  attr_accessor :cueva

end

# cave = Cave.dodecahedron
#
# rooms = (1..20).map { |i| cave.room(i)}
# rooms.each do |room|
#   room.neighbors.count == 3
#   room.neighbors.each { |i|
#     i.neighbors.include?(room) == true
# }
# end


# new_room = cave.random_room
# room = cave.random_room
# new_room = room.neighbors[1]
# room.neighbors.count
# room.has?(:pit) == true
# new_room.has?(:pit) == false
# cave.move(:pit, room, new_room)
# room.has?(:pit) == false
# new_room.has?(:pit) == true
# cave.add_hazard(:bats, 3)
# rooms_with_bats = rooms.select { |e|
# e.has?(:bats)}
# rooms_with_bats.count == 3
# cave.add_hazard(:guard, 1)
# cave.room_with(:guard).has?(:guard) == true
# entrance = cave.entrance
# entrance.safe? == true

class Player
  def initialize
    @r = nil
    @senses = Hash.new
    @encounters = Hash.new
    @actions = Hash.new
  end

  def sense(obj, &block)
    @senses[obj] = block.call
  end

  def encounter(obj, &block)
    @encounters[obj] = block.call
  end

  def action(actions, &block)
    @actions[actions] = room
  end

  def enter(room)
    @r = room
    for i in @encounters
      if i == @r.inside
        puts @encounters[i]
      end
    end
  end
  def explore_room
    j = 0
    for i in @senses
      while j != @r.neighbors.count
        if @r.neighbors[j].inside == i
          puts @senses[i]
        end
        j+=1
      end
    end
  end
  def act(action, room)
    for i in @actions
      if i == action
        @r = room
      end
    end
  end
  def room
    return @r
  end
end

# player = Player.new
# empty_room = Room.new(1)
# guard_room = Room.new(2)
# bats_room = Room.new(3)
# room4 = Room.new(4)
#
# sensed = Set.new
# encountered = Set.new
# empty_room.connect(guard_room)
# empty_room.connect(bats_room)
# player.sense(:bats) do
#   sensed.add("You hear a rustling")
# end
# player.sense(:guard) do
#   sensed.add("You smell something terrible")
# end
# player.encounter(:guard) do
#   encountered.add("The guard killed you")
# end
# player.encounter(:bats) do
#   encountered.add("The bats whisked you away")
# end
# player.action(:move) do |destination|
#   player.enter(destination)
# end
# empty_room.neighbors
# player.enter(empty_room)
# player.explore_room
# sensed == Set["You hear a rustling", "You smell something terrible"]
# encountered.empty? == true
# player = Player.new
# player.enter(bats_room)
# encountered == Set["The bats whisked you away"]
# sensed.empty? == true
# # perform actions on neighboring rooms player = Player.new
# player.act(:move, guard_room)
# player.room.number == guard_room.number
# encountered == Set["The guard killed you"]
# sensed.empty? == true
