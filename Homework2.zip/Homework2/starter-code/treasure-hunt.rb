class Console
  def initialize(player, narrator)
    @player   = player
    @narrator = narrator
  end

  def show_room_description
    @narrator.say "-----------------------------------------"
    @narrator.say "You are in room #{@player.room.number}."

    @player.explore_room

    @narrator.say "Exits go to: #{@player.room.exits.join(', ')}"
  end

  def ask_player_to_act
    actions = {"m" => :move, "s" => :shoot, "i" => :inspect }

    accepting_player_input do |command, room_number|
      @player.act(actions[command], @player.room.neighbor(room_number))
    end
  end

  private

  def accepting_player_input
    @narrator.say "-----------------------------------------"
    command = @narrator.ask("What do you want to do? (m)ove or (s)hoot?")

    unless ["m","s"].include?(command)
      @narrator.say "INVALID ACTION! TRY AGAIN!"
      return
    end

    dest = @narrator.ask("Where?").to_i

    unless @player.room.exits.include?(dest)
      @narrator.say "THERE IS NO PATH TO THAT ROOM! TRY AGAIN!"
      return
    end

    yield(command, dest)
  end
end

class Narrator
  def say(message)
    $stdout.puts message
  end

  def ask(question)
    print "#{question} "
    $stdin.gets.chomp
  end

  def tell_story
    yield until finished?

    say "-----------------------------------------"
    describe_ending
  end

  def finish_story(message)
    @ending_message = message
  end

  def finished?
    !!@ending_message
  end

  def describe_ending
    say @ending_message
  end
end

#-----------------------------------------------------------------

#Room Class
class Room
  #initializing room numbers
  def initialize(num)
    @num = num
    @insideRoom = []
    @connectedRooms = []
  end

  #getters
  def number
    @num
  end
  def neighbors
    @connectedRooms
  end
  def inside
    @insideRoom
  end

  #checking if room is empty
  def empty?
    if @insideRoom.empty?
      return true
    else
      return false
    end
  end

  #adding object to room
  def add(object)
    @insideRoom.append(object)
  end
  #removing object in room
  def remove(object)
    index = 0
    for i in @insideRoom
      if object == i
        @insideRoom.delete_at(index)
      else
        index +=1
      end
    end
  end
  #checking if room has object
  def has?(object)
    if @insideRoom.empty?
      return false
    else
      for i in @insideRoom
        if object == i
          return true
        else
          return false
        end
      end
    end
  end
  #connects room to one instance
  def connect(otherRoom)
    @connectedRooms.append(otherRoom)
    #should be bi-directional way
    otherRoom.neighbors.append(self)
    i = 0
    unless i = @connectedRooms.length
      if connectedRooms[i] == self
        self.remove(i)
      end
    end
  end

  #returns the neighbor
  def neighbor(nextRoom)
    for i in @connectedRooms
      if i.number == nextRoom
        return i
      end
    end
  end

  #returns the different exits of a room
  def exits
    arr = []
    for i in @connectedRooms
      arr.append(i.number)
    end
    return arr
  end

  #returns a random neighbor
  def random_neighbor
    random = rand(@connectedRooms.length)
    return @connectedRooms[random]
  end

  #checks if the room is safe
  def safe?
    if @insideRoom.empty?
      for i in @connectedRooms
        if i.empty?
          return true
        else return false
        end
      end
    else
      return false
    end
  end
end

#Cave Class
class Cave

  #creates an array that holds all of the rooms in the cave
  def initialize
    @@cueva = []
  end

  #hard coded layout of cave
  def self.dodecahedron
    cave = Cave.new()
    i = 1
    while i !=21
      room = Room.new(i)
      @@cueva.append(room)
      i +=1
    end
    for i in @@cueva
      if i.number == 1
        i.neighbors.append(@@cueva[1],@@cueva[4], @@cueva[7])
      elsif i.number == 2
        i.neighbors.append(@@cueva[0],@@cueva[2], @@cueva[9])
      elsif i.number == 3
        i.neighbors.append(@@cueva[3],@@cueva[11], @@cueva[1])
      elsif i.number == 4
        i.neighbors.append(@@cueva[2],@@cueva[4], @@cueva[13])
      elsif i.number == 5
        i.neighbors.append(@@cueva[0],@@cueva[5], @@cueva[3])
      elsif i.number == 6
        i.neighbors.append(@@cueva[4],@@cueva[6], @@cueva[14])
      elsif i.number == 7
        i.neighbors.append(@@cueva[5],@@cueva[16], @@cueva[7])
      elsif i.number == 8
        i.neighbors.append(@@cueva[6],@@cueva[10], @@cueva[0])
      elsif i.number == 9
        i.neighbors.append(@@cueva[9],@@cueva[11], @@cueva[18])
      elsif i.number == 10
        i.neighbors.append(@@cueva[10],@@cueva[8], @@cueva[1])
      elsif i.number == 11
        i.neighbors.append(@@cueva[19],@@cueva[9], @@cueva[7])
      elsif i.number == 12
        i.neighbors.append(@@cueva[12],@@cueva[2], @@cueva[8])
      elsif i.number == 13
        i.neighbors.append(@@cueva[11],@@cueva[17], @@cueva[13])
      elsif i.number == 14
        i.neighbors.append(@@cueva[12],@@cueva[14], @@cueva[3])
      elsif i.number == 15
        i.neighbors.append(@@cueva[5],@@cueva[15], @@cueva[13])
      elsif i.number == 16
        i.neighbors.append(@@cueva[16],@@cueva[17], @@cueva[14])
      elsif i.number == 17
        i.neighbors.append(@@cueva[15],@@cueva[19], @@cueva[6])
      elsif i.number == 18
        i.neighbors.append(@@cueva[18],@@cueva[15], @@cueva[12])
      elsif i.number == 19
        i.neighbors.append(@@cueva[8],@@cueva[19], @@cueva[17])
      else
        i.neighbors.append(@@cueva[18],@@cueva[10], @@cueva[16])
      end
    end
    return cave
  end

  #ensures that the room is in cave
  def room(rooms)
    for i in @@cueva
      if i.number == rooms
        return i
      end
    end
  end

  #allows you to select random room in Cave
  def random_room
    return @@cueva[rand(20)]
  end

  #can move objects from one room to another
  def move(obj, from, dest)
    for i in @@cueva
      if i == from
        i.remove(obj)
      end
    end
    for j in @@cueva
      if j == dest
        j.add(obj)
      end
    end
  end

  #add hazard into random rooms
  def add_hazard(obj, amount)
    j = 0
    while j != amount
      i = @@cueva[rand(@@cueva.length)]
      if i.has?(obj) == false
        i.add(obj)
      end
      j+=1
    end
  end

  #finds room if it has that
  def room_with(obj)
    for i in @@cueva
      if i.has?(obj)
        return i
      end
    end
  end

  #returns room that is safe
  def entrance
    for i in @@cueva
      if i.safe?
        return i
      end
    end
  end
  attr_accessor :cueva
end

#Player class
class Player

  #holds the hashes and room the player is in
  def initialize
    @r = nil
    @senses = Hash.new
    @encounters = Hash.new
    @actions = Hash.new
  end

  #stores the senses and the block
  def sense(obj, &block)
    @senses[obj] = block
  end

  #stores the encounters object and block
  def encounter(obj, &block)
    @encounters[obj] = block
  end

  #stores the actions and the room that it occurs in
  def action(actions, &room)
    @actions[actions] = room
  end

  #allows player to enter room and check the room for hazards
  def enter(room)
    @r = room
    if @r.inside.empty? == false
      for i in @r.inside
        for j in @encounters
          if i == j
            @encounters[i.to_sym]
          end
        end
      end
    else
      print "nothing"
    end
  end

  #allows player to sense if neighboring rooms have objects inside
  def explore_room
    j = 0
    for i in @senses
      while j != @r.neighbors.count
        if @r.neighbors[j].inside == i
          @senses[i].call
        end
        j+=1
      end
    end
  end

  #allows player to act on actions
  def act(action, room)
    @r = room
    @actions = {action => @r}
  end

  #returns the room the player is currently in
  def room
    return @r
  end
end

e = Room.new(1)
b = Room.new(2)
player = Player.new
puts player.enter(e)
