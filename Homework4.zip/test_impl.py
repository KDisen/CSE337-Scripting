#Keven Disen
#111433335
#CSE 337 Assignment 4 Part 2
#12/6/2020

import unittest
from impl import PhysicalInfo

class TestPhysicalInfo(unittest.TestCase):
    def setUp(self):
        self.info = PhysicalInfo()

    #Set Name
    def test_setName_method(self):
        correctName = ["keven", "ke-21", "Ia", "kaiden", "L rry", "X Æ A-12", "A21", "alpha", "CSE"]
        for i in correctName:
            self.assertEqual(None, self.info.set_name(i))

    def test_setName_raises(self):
        incorrectName = ["k=3a", 123, "J", " ", "1", "!@#", "k2@", "k)1", 9, "$", "La==y", "C$3"]
        for i in incorrectName:
            with self.assertRaises(ValueError):
                self.info.set_name(i)

    #Set Date
    def test_setDate_method(self):
        correctDate = ["12-23-2001", "11-31-2020", "01-02-1999", "31-12-2007", "22-02-2000", "30-02-1998", "12-05-1999",
                       "25-06-1901", "05-29-1900", "07-07-2100"]
        for i in correctDate:
            self.assertEqual(i, self.info.set_date(i))

    def test_setDate_raises(self):
        incorrectDate = ["31-25-2020", "31-12-1899", "05-25-2101", "5", "05-", "70-04", " ", "28-25-2825", "12-35-1900",
                         "09-45-22", 2, 11-12-2000]
        for i in incorrectDate:
            self.assertRaises(ValueError, self.info.set_date(i))

    #Set Gender
    def test_setGender_method(self):
        correctGender = ["M", "F"]
        for i in correctGender:
            self.assertEqual(None, self.info.set_gender(i))

    def test_setGender_raises(self):
        incorrectGender = [1, 2, "S", "B", "-", "!", "ED", "MF", 2.5, "#$", "G"]
        for i in incorrectGender:
            with self.assertRaises(ValueError):
                self.info.set_gender(i)

    #Set Height
    def test_setHeight_method(self):
        correctHeight = [18, 20, 17, 84, 25, 20, 76, 65, 80, 34]
        for i in correctHeight:
            self.assertEqual(None, self.info.set_height(i))

    def test_setHeight_raises(self):
        incorrectHeight = ["18", "-", 14, 85, 99, 14, 100, "20", "2)", " ", "2!", 1]
        for i in incorrectHeight:
            with self.assertRaises(ValueError):
                self.info.set_height(i)

    #Set Temperature
    def test_setTemp_method(self):
        correctTemp = [95.0, 100.54, 104.0, 98.9, 96.7, 95.1, 98.9, 103.9, 97.8, 101.1]
        for i in correctTemp:
            self.assertEqual(None, self.info.set_temperature(i))

    def test_setTemp_raises(self):
        incorrectTemp = ["100", 103, 106, 90, "!", "10", 15, 30, " ", 94.99, "10#"]
        for i in incorrectTemp:
            with self.assertRaises(ValueError):
                self.info.set_temperature(i)


if __name__ == '__main__':
    unittest.main()
